<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.htmlcodex.com/1858/startup-website-template/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 28 Apr 2024 18:03:32 GMT -->
<head>
<meta charset="utf-8">
<title>Startup - Startup Website Template</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="Free HTML Templates" name="keywords">
<meta content="Free HTML Templates" name="description">

<link href="img/favicon.html" rel="icon">

<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&amp;family=Rubik:wght@400;500;600;700&amp;display=swap" rel="stylesheet">

<link href="../../../cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="../../../cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">

<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/animate/animate.min.css" rel="stylesheet">

<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">
</head>
<body>

<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
<div class="spinner"></div>
</div>


<div class="container-fluid bg-dark px-5 d-none d-lg-block">
<div class="row gx-0">
<div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
<div class="d-inline-flex align-items-center" style="height: 45px;">
<small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>123 Street, New York, USA</small>
<small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+012 345 6789</small>
<small class="text-light"><i class="fa fa-envelope-open me-2"></i><a href="https://demo.htmlcodex.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="452c2b232a05203d24283529206b262a28">[email&#160;protected]</a></small>
</div>
</div>
<div class="col-lg-4 text-center text-lg-end">
<div class="d-inline-flex align-items-center" style="height: 45px;">
<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href><i class="fab fa-twitter fw-normal"></i></a>
<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href><i class="fab fa-facebook-f fw-normal"></i></a>
<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href><i class="fab fa-linkedin-in fw-normal"></i></a>
<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href><i class="fab fa-instagram fw-normal"></i></a>
<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle" href><i class="fab fa-youtube fw-normal"></i></a>
</div>
</div>
</div>
</div>


<div class="container-fluid position-relative p-0">
<nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0">
<a href="index.html" class="navbar-brand p-0">
<h1 class="m-0"><i class="fa fa-user-tie me-2"></i>Startup</h1>
</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
<span class="fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse" id="navbarCollapse">
<div class="navbar-nav ms-auto py-0">
<a href="index.html" class="nav-item nav-link">Home</a>
<a href="about.html" class="nav-item nav-link">About</a>
<a href="service.html" class="nav-item nav-link">Services</a>
<div class="nav-item dropdown">
<a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown">Blog</a>
<div class="dropdown-menu m-0">
<a href="blog.html" class="dropdown-item active">Blog Grid</a>
<a href="detail.html" class="dropdown-item">Blog Detail</a>
</div>
</div>
<div class="nav-item dropdown">
<a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
<div class="dropdown-menu m-0">
<a href="price.html" class="dropdown-item">Pricing Plan</a>
<a href="feature.html" class="dropdown-item">Our features</a>
<a href="team.html" class="dropdown-item">Team Members</a>
<a href="testimonial.html" class="dropdown-item">Testimonial</a>
<a href="quote.html" class="dropdown-item">Free Quote</a>
</div>
</div>
<a href="contact.html" class="nav-item nav-link">Contact</a>
</div>
<butaton type="button" class="btn text-primary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="fa fa-search"></i></butaton>
<a href="https://htmlcodex.com/startup-company-website-template" class="btn btn-primary py-2 px-4 ms-3">Download Pro Version</a>
</div>
</nav>
<div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
<div class="row py-5">
<div class="col-12 pt-lg-5 mt-lg-5 text-center">
<h1 class="display-4 text-white animated zoomIn">Blog Grid</h1>
<a href class="h5 text-white">Home</a>
<i class="far fa-circle text-white px-2"></i>
<a href class="h5 text-white">Blog Grid</a>
</div>
</div>
</div>
</div>


<div class="modal fade" id="searchModal" tabindex="-1">
<div class="modal-dialog modal-fullscreen">
<div class="modal-content" style="background: rgba(9, 30, 62, .7);">
<div class="modal-header border-0">
<button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body d-flex align-items-center justify-content-center">
<div class="input-group" style="max-width: 600px;">
<input type="text" class="form-control bg-transparent border-primary p-3" placeholder="Type search keyword">
<button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
</div>
</div>
</div>
</div>
</div>


<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
<div class="container py-5">
<div class="row g-5">

<div class="col-lg-8">
<div class="row g-5">
<div class="col-md-6 wow slideInUp" data-wow-delay="0.1s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-1.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.6s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-2.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.1s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-3.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.6s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-1.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.1s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-2.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.6s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-3.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.1s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-1.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.6s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-2.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.1s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-3.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-md-6 wow slideInUp" data-wow-delay="0.6s">
<div class="blog-item bg-light rounded overflow-hidden">
<div class="blog-img position-relative overflow-hidden">
<img class="img-fluid" src="img/blog-1.jpg" alt>
<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href>Web Design</a>
</div>
<div class="p-4">
<div class="d-flex mb-3">
<small class="me-3"><i class="far fa-user text-primary me-2"></i>John Doe</small>
<small><i class="far fa-calendar-alt text-primary me-2"></i>01 Jan, 2045</small>
</div>
<h4 class="mb-3">How to build a website</h4>
<p>Dolor et eos labore stet justo sed est sed sed sed dolor stet amet</p>
<a class="text-uppercase" href>Read More <i class="bi bi-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-12 wow slideInUp" data-wow-delay="0.1s">
<nav aria-label="Page navigation">
<ul class="pagination pagination-lg m-0">
<li class="page-item disabled">
<a class="page-link rounded-0" href="#" aria-label="Previous">
<span aria-hidden="true"><i class="bi bi-arrow-left"></i></span>
</a>
</li>
<li class="page-item active"><a class="page-link" href="#">1</a></li>
<li class="page-item"><a class="page-link" href="#">2</a></li>
<li class="page-item"><a class="page-link" href="#">3</a></li>
<li class="page-item">
<a class="page-link rounded-0" href="#" aria-label="Next">
<span aria-hidden="true"><i class="bi bi-arrow-right"></i></span>
</a>
</li>
</ul>
</nav>
</div>
</div>
</div>


<div class="col-lg-4">

<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
<div class="input-group">
<input type="text" class="form-control p-3" placeholder="Keyword">
<button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
</div>
</div>


<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="mb-0">Categories</h3>
</div>
<div class="link-animated d-flex flex-column justify-content-start">
<a class="h5 fw-semi-bold bg-light rounded py-2 px-3 mb-2" href="#"><i class="bi bi-arrow-right me-2"></i>Web Design</a>
<a class="h5 fw-semi-bold bg-light rounded py-2 px-3 mb-2" href="#"><i class="bi bi-arrow-right me-2"></i>Web Development</a>
<a class="h5 fw-semi-bold bg-light rounded py-2 px-3 mb-2" href="#"><i class="bi bi-arrow-right me-2"></i>Web Development</a>
<a class="h5 fw-semi-bold bg-light rounded py-2 px-3 mb-2" href="#"><i class="bi bi-arrow-right me-2"></i>Keyword Research</a>
<a class="h5 fw-semi-bold bg-light rounded py-2 px-3 mb-2" href="#"><i class="bi bi-arrow-right me-2"></i>Email Marketing</a>
</div>
</div>


<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="mb-0">Recent Post</h3>
</div>
<div class="d-flex rounded overflow-hidden mb-3">
<img class="img-fluid" src="img/blog-1.jpg" style="width: 100px; height: 100px; object-fit: cover;" alt>
<a href class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">Lorem ipsum dolor sit amet adipis elit
</a>
</div>
<div class="d-flex rounded overflow-hidden mb-3">
<img class="img-fluid" src="img/blog-2.jpg" style="width: 100px; height: 100px; object-fit: cover;" alt>
<a href class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">Lorem ipsum dolor sit amet adipis elit
</a>
</div>
<div class="d-flex rounded overflow-hidden mb-3">
<img class="img-fluid" src="img/blog-3.jpg" style="width: 100px; height: 100px; object-fit: cover;" alt>
<a href class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">Lorem ipsum dolor sit amet adipis elit
</a>
</div>
<div class="d-flex rounded overflow-hidden mb-3">
<img class="img-fluid" src="img/blog-1.jpg" style="width: 100px; height: 100px; object-fit: cover;" alt>
<a href class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">Lorem ipsum dolor sit amet adipis elit
</a>
</div>
<div class="d-flex rounded overflow-hidden mb-3">
<img class="img-fluid" src="img/blog-2.jpg" style="width: 100px; height: 100px; object-fit: cover;" alt>
<a href class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">Lorem ipsum dolor sit amet adipis elit
</a>
</div>
<div class="d-flex rounded overflow-hidden mb-3">
<img class="img-fluid" src="img/blog-3.jpg" style="width: 100px; height: 100px; object-fit: cover;" alt>
<a href class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">Lorem ipsum dolor sit amet adipis elit
</a>
</div>
</div>


<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
<img src="img/blog-1.jpg" alt class="img-fluid rounded">
</div>


<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="mb-0">Tag Cloud</h3>
</div>
<div class="d-flex flex-wrap m-n1">
<a href class="btn btn-light m-1">Design</a>
<a href class="btn btn-light m-1">Development</a>
<a href class="btn btn-light m-1">Marketing</a>
<a href class="btn btn-light m-1">SEO</a>
<a href class="btn btn-light m-1">Writing</a>
<a href class="btn btn-light m-1">Consulting</a>
<a href class="btn btn-light m-1">Design</a>
<a href class="btn btn-light m-1">Development</a>
<a href class="btn btn-light m-1">Marketing</a>
<a href class="btn btn-light m-1">SEO</a>
<a href class="btn btn-light m-1">Writing</a>
<a href class="btn btn-light m-1">Consulting</a>
</div>
</div>


<div class="wow slideInUp" data-wow-delay="0.1s">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="mb-0">Plain Text</h3>
</div>
<div class="bg-light text-center" style="padding: 30px;">
<p>Vero sea et accusam justo dolor accusam lorem consetetur, dolores sit amet sit dolor clita kasd justo, diam accusam no sea ut tempor magna takimata, amet sit et diam dolor ipsum amet diam</p>
<a href class="btn btn-primary py-2 px-4">Read More</a>
</div>
</div>

</div>

</div>
</div>
</div>


<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
<div class="container py-5 mb-5">
<div class="bg-white">
<div class="owl-carousel vendor-carousel">
<img src="img/vendor-1.jpg" alt>
<img src="img/vendor-2.jpg" alt>
<img src="img/vendor-3.jpg" alt>
<img src="img/vendor-4.jpg" alt>
<img src="img/vendor-5.jpg" alt>
<img src="img/vendor-6.jpg" alt>
<img src="img/vendor-7.jpg" alt>
<img src="img/vendor-8.jpg" alt>
<img src="img/vendor-9.jpg" alt>
</div>
</div>
</div>
</div>


<div class="container-fluid bg-dark text-light mt-5 wow fadeInUp" data-wow-delay="0.1s">
<div class="container">
<div class="row gx-5">
<div class="col-lg-4 col-md-6 footer-about">
<div class="d-flex flex-column align-items-center justify-content-center text-center h-100 bg-primary p-4">
<a href="index.html" class="navbar-brand">
<h1 class="m-0 text-white"><i class="fa fa-user-tie me-2"></i>Startup</h1>
</a>
<p class="mt-3 mb-4">Lorem diam sit erat dolor elitr et, diam lorem justo amet clita stet eos sit. Elitr dolor duo lorem, elitr clita ipsum sea. Diam amet erat lorem stet eos. Diam amet et kasd eos duo.</p>
<form action>
<div class="input-group">
<input type="text" class="form-control border-white p-3" placeholder="Your Email">
<button class="btn btn-dark">Sign Up</button>
</div>
</form>
</div>
</div>
<div class="col-lg-8 col-md-6">
<div class="row gx-5">
<div class="col-lg-4 col-md-12 pt-5 mb-5">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="text-light mb-0">Get In Touch</h3>
</div>
<div class="d-flex mb-2">
<i class="bi bi-geo-alt text-primary me-2"></i>
<p class="mb-0">123 Street, New York, USA</p>
</div>
<div class="d-flex mb-2">
<i class="bi bi-envelope-open text-primary me-2"></i>
<p class="mb-0"><a href="https://demo.htmlcodex.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="70191e161f301508111d001c155e131f1d">[email&#160;protected]</a></p>
</div>
<div class="d-flex mb-2">
<i class="bi bi-telephone text-primary me-2"></i>
<p class="mb-0">+012 345 67890</p>
</div>
<div class="d-flex mt-4">
<a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-twitter fw-normal"></i></a>
<a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-facebook-f fw-normal"></i></a>
<a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-linkedin-in fw-normal"></i></a>
<a class="btn btn-primary btn-square" href="#"><i class="fab fa-instagram fw-normal"></i></a>
</div>
</div>
<div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="text-light mb-0">Quick Links</h3>
</div>
<div class="link-animated d-flex flex-column justify-content-start">
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Home</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>About Us</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Our Services</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Meet The Team</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Latest Blog</a>
<a class="text-light" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Contact Us</a>
</div>
</div>
<div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
<div class="section-title section-title-sm position-relative pb-3 mb-4">
<h3 class="text-light mb-0">Popular Links</h3>
</div>
<div class="link-animated d-flex flex-column justify-content-start">
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Home</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>About Us</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Our Services</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Meet The Team</a>
<a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Latest Blog</a>
<a class="text-light" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Contact Us</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container-fluid text-white" style="background: #061429;">
<div class="container text-center">
<div class="row justify-content-end">
<div class="col-lg-8 col-md-6">
<div class="d-flex align-items-center justify-content-center" style="height: 75px;">
<p class="mb-0">&copy; <a class="text-white border-bottom" href="#">Your Site Name</a>. All Rights Reserved. Designed by <a class="text-white border-bottom" href="https://htmlcodex.com/">HTML Codex</a></p>
</div>
</div>
</div>
</div>
</div>


<a href="#" class="btn btn-lg btn-primary btn-lg-square rounded back-to-top"><i class="bi bi-arrow-up"></i></a>

<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="../../../code.jquery.com/jquery-3.4.1.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="../../../cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="lib/wow/wow.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="lib/easing/easing.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="lib/waypoints/waypoints.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="lib/counterup/counterup.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="lib/owlcarousel/owl.carousel.min.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>

<script src="js/main.js" type="ffd55432751a3ec6e5c9f6d2-text/javascript"></script>
<script src="../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="ffd55432751a3ec6e5c9f6d2-|49" defer></script></body>

<!-- Mirrored from demo.htmlcodex.com/1858/startup-website-template/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 28 Apr 2024 18:03:32 GMT -->
</html>