<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Code Crush</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Code Crush Website" name="keywords">
    <meta content="Code Crush Website" name="description">
    <link href="img/favicon.php" rel="icon">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&amp;family=Rubik:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
    <link href="cloud/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="cdnjs/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body>
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
      <div class="spinner"></div>
    </div>
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
      <div class="row gx-0">
        <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
          <div class="d-inline-flex align-items-center" style="height: 45px;">
            <small class="me-3 text-light">
              <i class="fa fa-map-marker-alt me-2"></i>Mumbai Maharashtra </small>
            <small class="me-3 text-light">
              <i class="fa fa-phone-alt me-2"></i>9999999999 </small>
            <small class="text-light">
              <i class="fa fa-envelope-open me-2"></i>info@codecrush.com </small>
          </div>
        </div>
        <div class="col-lg-4 text-center text-lg-end">
          <div class="d-inline-flex align-items-center" style="height: 45px;">
            <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href>
              <i class="fab fa-twitter fw-normal"></i>
            </a>
            <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href>
              <i class="fab fa-facebook-f fw-normal"></i>
            </a>
            <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href>
              <i class="fab fa-linkedin-in fw-normal"></i>
            </a>
            <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href>
              <i class="fab fa-instagram fw-normal"></i>
            </a>
            <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle" href>
              <i class="fab fa-youtube fw-normal"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid position-relative p-0">
      <nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0">
        <a href="index.php" class="navbar-brand p-0">
          <h1 class="m-0">
            <i class="fa fa-user-tie me-2"></i>Code Crush
          </h1>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
          <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <div class="navbar-nav ms-auto py-0">
            <a href="index.php" class="nav-item nav-link">Home</a>
            <a href="about.php" class="nav-item nav-link">About Us</a>
            <div class="nav-item dropdown">
              <a href="service.php" class="nav-link active dropdown-toggle" data-bs-toggle="dropdown">Services</a>
              <div class="dropdown-menu m-0">
                <a href="service.php" class="dropdown-item">Services 1</a>
                <a href="service.php" class="dropdown-item">Services 2</a>
              </div>
            </div>
            <a href="feature.php" class="nav-item nav-link">Our Feature</a>
            <a href="team.php" class="nav-item nav-link">Team Members</a>
            <a href="testimonial.php" class="nav-item nav-link">Testimonial</a>
            <a href="contact.php" class="nav-item nav-link">Contact</a>
          </div>
        </div>
      </nav>
<div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
<div class="row py-5">
<div class="col-12 pt-lg-5 mt-lg-5 text-center">
<h1 class="display-4 text-white animated zoomIn">Services</h1>
<a href class="h5 text-white">Home</a>
<i class="far fa-circle text-white px-2"></i>
<a href class="h5 text-white">Services</a>
</div>
</div>
</div>
</div>


<div class="modal fade" id="searchModal" tabindex="-1">
<div class="modal-dialog modal-fullscreen">
<div class="modal-content" style="background: rgba(9, 30, 62, .7);">
<div class="modal-header border-0">
<button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body d-flex align-items-center justify-content-center">
<div class="input-group" style="max-width: 600px;">
<input type="text" class="form-control bg-transparent border-primary p-3" placeholder="Type search keyword">
<button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
</div>
</div>
</div>
</div>
</div>


<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
<div class="container py-5">
<div class="section-title text-center position-relative pb-3 mb-5 mx-auto" style="max-width: 600px;">
<h5 class="fw-bold text-primary text-uppercase">Our Services</h5>
<h1 class="mb-0">Custom IT Solutions for Your Successful Business</h1>
</div>
<div class="row g-5">
<div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
<div class="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
<div class="service-icon">
<i class="fa fa-shield-alt text-white"></i>
</div>
<h4 class="mb-3">Cyber Security</h4>
<p class="m-0">Amet justo dolor lorem kasd amet magna sea stet eos vero lorem ipsum dolore sed</p>
<a class="btn btn-lg btn-primary rounded" href>
<i class="bi bi-arrow-right"></i>
</a>
</div>
</div>
<div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.6s">
<div class="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
<div class="service-icon">
<i class="fa fa-chart-pie text-white"></i>
</div>
<h4 class="mb-3">Data Analytics</h4>
<p class="m-0">Amet justo dolor lorem kasd amet magna sea stet eos vero lorem ipsum dolore sed</p>
<a class="btn btn-lg btn-primary rounded" href>
<i class="bi bi-arrow-right"></i>
</a>
</div>
</div>
<div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.9s">
<div class="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
<div class="service-icon">
<i class="fa fa-code text-white"></i>
</div>
<h4 class="mb-3">Web Development</h4>
<p class="m-0">Amet justo dolor lorem kasd amet magna sea stet eos vero lorem ipsum dolore sed</p>
<a class="btn btn-lg btn-primary rounded" href>
<i class="bi bi-arrow-right"></i>
</a>
</div>
</div>
<div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
<div class="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
<div class="service-icon">
<i class="fab fa-android text-white"></i>
</div>
<h4 class="mb-3">Apps Development</h4>
<p class="m-0">Amet justo dolor lorem kasd amet magna sea stet eos vero lorem ipsum dolore sed</p>
<a class="btn btn-lg btn-primary rounded" href>
<i class="bi bi-arrow-right"></i>
</a>
</div>
</div>
<div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.6s">
<div class="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
<div class="service-icon">
<i class="fa fa-search text-white"></i>
</div>
<h4 class="mb-3">SEO Optimization</h4>
<p class="m-0">Amet justo dolor lorem kasd amet magna sea stet eos vero lorem ipsum dolore sed</p>
<a class="btn btn-lg btn-primary rounded" href>
<i class="bi bi-arrow-right"></i>
</a>
</div>
</div>
<div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.9s">
<div class="position-relative bg-primary rounded h-100 d-flex flex-column align-items-center justify-content-center text-center p-5">
<h3 class="text-white mb-3">Call Us For Quote</h3>
<p class="text-white mb-3">Clita ipsum magna kasd rebum at ipsum amet dolor justo dolor est magna stet eirmod</p>
<h2 class="text-white mb-0">+012 345 6789</h2>
</div>
</div>
</div>
</div>
</div>


<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
<div class="container py-5">
<div class="section-title text-center position-relative pb-3 mb-4 mx-auto" style="max-width: 600px;">
<h5 class="fw-bold text-primary text-uppercase">Testimonial</h5>
<h1 class="mb-0">What Our Clients Say About Our Digital Services</h1>
</div>
<div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.6s">
<div class="testimonial-item bg-light my-4">
<div class="d-flex align-items-center border-bottom pt-5 pb-4 px-5">
<img class="img-fluid rounded" src="img/testimonial-1.jpg" style="width: 60px; height: 60px;">
<div class="ps-4">
<h4 class="text-primary mb-1">Client Name</h4>
<small class="text-uppercase">Profession</small>
</div>
</div>
<div class="pt-4 pb-5 px-5">
Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
</div>
</div>
<div class="testimonial-item bg-light my-4">
<div class="d-flex align-items-center border-bottom pt-5 pb-4 px-5">
<img class="img-fluid rounded" src="img/testimonial-2.jpg" style="width: 60px; height: 60px;">
<div class="ps-4">
<h4 class="text-primary mb-1">Client Name</h4>
<small class="text-uppercase">Profession</small>
</div>
</div>
<div class="pt-4 pb-5 px-5">
Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
</div>
</div>
<div class="testimonial-item bg-light my-4">
<div class="d-flex align-items-center border-bottom pt-5 pb-4 px-5">
<img class="img-fluid rounded" src="img/testimonial-3.jpg" style="width: 60px; height: 60px;">
<div class="ps-4">
<h4 class="text-primary mb-1">Client Name</h4>
<small class="text-uppercase">Profession</small>
</div>
</div>
<div class="pt-4 pb-5 px-5">
Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
</div>
</div>
<div class="testimonial-item bg-light my-4">
<div class="d-flex align-items-center border-bottom pt-5 pb-4 px-5">
<img class="img-fluid rounded" src="img/testimonial-4.jpg" style="width: 60px; height: 60px;">
<div class="ps-4">
<h4 class="text-primary mb-1">Client Name</h4>
<small class="text-uppercase">Profession</small>
</div>
</div>
<div class="pt-4 pb-5 px-5">
Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
</div>
</div>
</div>
</div>
</div>


<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
<div class="container py-5 mb-5">
<div class="bg-white">
<div class="owl-carousel vendor-carousel">
<img src="img/vendor-1.jpg" alt>
<img src="img/vendor-2.jpg" alt>
<img src="img/vendor-3.jpg" alt>
<img src="img/vendor-4.jpg" alt>
<img src="img/vendor-5.jpg" alt>
<img src="img/vendor-6.jpg" alt>
<img src="img/vendor-7.jpg" alt>
<img src="img/vendor-8.jpg" alt>
<img src="img/vendor-9.jpg" alt>
</div>
</div>
</div>
</div>


<div class="container-fluid bg-dark text-light mt-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="container">
        <div class="row gx-5">
          <div class="col-lg-4 col-md-6 footer-about">
            <div class="d-flex flex-column align-items-center justify-content-center text-center h-100 bg-primary p-4">
              <a href="index.php" class="navbar-brand">
                <h1 class="m-0 text-white">
                  <i class="fa fa-user-tie me-2"></i>Code Crush
                </h1>
              </a>
              <p class="mt-3 mb-4">Lorem diam sit erat dolor elitr et, diam lorem justo amet clita stet eos sit. Elitr dolor duo lorem, elitr clita ipsum sea. Diam amet erat lorem stet eos. Diam amet et kasd eos duo.</p>
              <form action>
                <div class="input-group">
                  <input type="text" class="form-control border-white p-3" placeholder="Your Email">
                  <button class="btn btn-dark">Sign Up</button>
                </div>
              </form>
            </div>
          </div>
          <div class="col-lg-8 col-md-6">
            <div class="row gx-5">
              <div class="col-lg-4 col-md-12 pt-5 mb-5">
                <div class="section-title section-title-sm position-relative pb-3 mb-4">
                  <h3 class="text-light mb-0">Get In Touch</h3>
                </div>
                <div class="d-flex mb-2">
                  <i class="bi bi-geo-alt text-primary me-2"></i>
                  <p class="mb-0">Mumbai Maharashtra</p>
                </div>
                <div class="d-flex mb-2">
                  <i class="bi bi-envelope-open text-primary me-2"></i>
                  <p class="mb-0">info@codecrush.com</p>
                </div>
                <div class="d-flex mb-2">
                  <i class="bi bi-telephone text-primary me-2"></i>
                  <p class="mb-0">9999999999</p>
                </div>
                <div class="d-flex mt-4">
                  <a class="btn btn-primary btn-square me-2" href="#">
                    <i class="fab fa-twitter fw-normal"></i>
                  </a>
                  <a class="btn btn-primary btn-square me-2" href="#">
                    <i class="fab fa-facebook-f fw-normal"></i>
                  </a>
                  <a class="btn btn-primary btn-square me-2" href="#">
                    <i class="fab fa-linkedin-in fw-normal"></i>
                  </a>
                  <a class="btn btn-primary btn-square" href="#">
                    <i class="fab fa-instagram fw-normal"></i>
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                <div class="section-title section-title-sm position-relative pb-3 mb-4">
                  <h3 class="text-light mb-0">Quick Links</h3>
                </div>
                <div class="link-animated d-flex flex-column justify-content-start">
                  <a class="text-light mb-2" href="index.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Home </a>
                  <a class="text-light mb-2" href="about.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>About Us </a>
                  <a class="text-light mb-2" href="service.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Our Services </a>
                  <a class="text-light mb-2" href="team.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Meet The Team </a>
                  <a class="text-light mb-2" href="testimonial.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Testimonials </a>
                  <a class="text-light" href="contact.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Contact Us </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                <div class="section-title section-title-sm position-relative pb-3 mb-4">
                  <h3 class="text-light mb-0">Popular Links</h3>
                </div>
                <div class="link-animated d-flex flex-column justify-content-start">
                  <a class="text-light mb-2" href="index.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Home </a>
                  <a class="text-light mb-2" href="about.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>About Us </a>
                  <a class="text-light mb-2" href="service.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Our Services </a>
                  <a class="text-light mb-2" href="team.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Meet The Team </a>
                  <a class="text-light mb-2" href="feature.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Our Features </a>
                  <a class="text-light" href="contact.php">
                    <i class="bi bi-arrow-right text-primary me-2"></i>Contact Us </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid text-white" style="background: #061429;">
      <div class="container text-center">
        <div class="row justify-content-end">
          <div class="col-lg-8 col-md-6">
            <div class="d-flex align-items-center justify-content-center" style="height: 75px;">
              <p class="mb-0">&copy; <a class="text-white border-bottom" href="#">Code Crush</a>. All Rights Reserved. </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded back-to-top">
      <i class="bi bi-arrow-up"></i>
    </a>
    <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="code.jquery.com/jquery-3.4.1.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="cdnjs/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="lib/wow/wow.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="lib/easing/easing.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="lib/waypoints/waypoints.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="lib/counterup/counterup.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="js/main.js" type="2bb81b16fc0d0ee347d51386-text/javascript"></script>
    <script src="cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="2bb81b16fc0d0ee347d51386-|49" defer></script>
  </body>
</html>